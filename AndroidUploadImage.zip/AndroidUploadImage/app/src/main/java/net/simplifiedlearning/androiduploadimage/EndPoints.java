package net.simplifiedlearning.androiduploadimage;

/**
 * Created by Belal on 10/24/2017.
 */

public class EndPoints {
    private static final String ROOT_URL = " https://damp-wave-49064.herokuapp.com/home/5";
    public static final String UPLOAD_URL = ROOT_URL;
    public static final String GET_PICS_URL = ROOT_URL + "getpics";
}
